


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-info" style="color: black !important;">
        <div class="inner">
          <p>FRET IMPAYÉS</p>
          <h5>QTE : <?php echo e($impayes->where('is_fret', 1)->where('is_solded', 0)->count()); ?></h5>
          <h5>MONTANT : <?php echo e(number_format($impayes->where('is_fret', 1)->where('is_solded', 0)->sum('prix'), 0, '', ' ')); ?></h5>
        </div>
        <div class="icon">
          <i class="ion ion-bag"></i>
        </div>
        <a href="<?php echo e(route('rapport-tickets-impayes', ['is_solded' => 0, 'is_fret' => 1])); ?>" class="small-box-footer">Détails <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-success" style="color: black !important;">
        <div class="inner">
          <p>FRET PAYÉS</p>
          <h5>QTE : <?php echo e($impayes->where('is_fret', 1)->where('is_solded', 1)->count()); ?></h5>
          <h5>MONTANT : <?php echo e(number_format($impayes->where('is_fret', 1)->where('is_solded', 1)->sum('prix'), 0, '', ' ')); ?></h5>
        </div>
        <div class="icon">
          <i class="ion ion-pie-graph"></i>
        </div>
        <a href="<?php echo e(route('rapport-tickets-impayes', ['is_solded' => 1, 'is_fret' => 1])); ?>" class="small-box-footer">Détails <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-danger" style="color: black !important;">
        <div class="inner">
          <p>BAGAGES IMPAYÉS</p>
          <h5>QTE : <?php echo e($impayes->where('is_fret', 0)->where('is_solded', 0)->count()); ?></h5>
          <h5>MONTANT : <?php echo e(number_format($impayes->where('is_fret', 0)->where('is_solded', 0)->sum('prix'), 0, '', ' ')); ?></h5>
        </div>
        <div class="icon">
          <i class="ion ion-person-add"></i>
        </div>
        <a href="<?php echo e(route('rapport-tickets-impayes', ['is_solded' => 0, 'is_fret' => 0])); ?>" class="small-box-footer">Détails <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
    <div class="col-lg-3 col-6">
      <!-- small box -->
      <div class="small-box bg-warning" style="color: black !important;">
        <div class="inner">
          <p>BAGAGES PAYÉS</p>
          <h5>QTE : <?php echo e($impayes->where('is_fret', 0)->where('is_solded', 1)->count()); ?></h5>
          <h5>MONTANT : <?php echo e(number_format($impayes->where('is_fret', 0)->where('is_solded', 1)->sum('prix'), 0, '', ' ')); ?></h5>
        </div>
        <div class="icon">
          <i class="ion ion-pie-graph"></i>
        </div>
        <a href="<?php echo e(route('rapport-tickets-impayes', ['is_solded' => 1, 'is_fret' => 0])); ?>" class="small-box-footer text-white" style="color: white !important;">Détails <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
    <!-- ./col -->
  </div>


<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title"> <strong>TICKETS IMPAYÉS </strong> </h3>
          
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>CODE</th>
                <th>GARE</th>
                <th>CLIENT</th>
                <th>BAGAGE</th>
                <th>TYPE</th>
                <th>QUANTITE</th>
                <th>PRIX</th>
                <th>PHOTO</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $impayes->where('is_solded', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td><?php echo e($item->ref); ?></td>
                  <td><?php echo e($item->nom_gare); ?></td>
                  <td><?php echo e($item->name_passager); ?> <br> <?php echo e($item->phone_passager); ?></td>
                  <td><?php echo e($item->type_bagage); ?></td>
                  <td><?php echo e($item->is_fret == 1 ? "FRET" : "BUS"); ?></td>
                  <td><?php echo e($item->nbr_de_bagage); ?></td>
                  <td><?php echo e(number_format($item->prix, 0, '', ' ')); ?></td>
                  <td>
                      <a href="https://ocl.ci/storage/bagages/<?php echo e($item->image); ?>" target="_blank" class="btn btn-secondary"> Voir l'image</a>
                  </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">  <strong>IMPAYÉS PAR GARE</strong> </h3>
          
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example3" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>GARE</th>
                <th>QTE CLIENT</th>
                <th>QTE BAGAGE</th>
                <th>MONTANT ( FCFA )</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $impayesGroupByGare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td><?php echo e($item->nom_gare); ?></td>
                  <td><?php echo e(number_format($item->qte_client, 0, '', ' ')); ?></td>
                  <td><?php echo e(number_format($item->qte_bagage, 0, '', ' ')); ?></td>
                  <td><?php echo e(number_format($item->prix_gare, 0, '', ' ')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/tickets-impayes.blade.php ENDPATH**/ ?>