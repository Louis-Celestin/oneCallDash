

<?php $__env->startSection('content'); ?>
<div class="card my-2">
  <div class="card-body mx-auto">
      <form action="<?php echo e(route('filtre-remises')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <div class="row d-flex justify-content-center">
              <div class="mx-2">
                  <div class="form-group">
                      <label for="datestart" class="text-muted">Début </label>
      
                      <div class="input-group">
                          <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                          </div>
                          <input type="date" id="datestart" class="form-control" name="start"  data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" inputmode="numeric" value="<?php echo e(session()->has('start') ? session()->get('start') : date('Y-m-d')); ?>">
                      </div>
                      <!-- /.input group -->
                  </div>
              </div>
              <div class="mx-2">
                  <div class="form-group">
                      <label for="dateend" class="text-muted">Fin </label>
      
                      <div class="input-group">
                          <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                          </div>
                          <input type="date" id="dateend" class="form-control" name="end"  data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" inputmode="numeric" value="<?php echo e(session()->has('end') ? session()->get('end') : date('Y-m-d')); ?>">
                      </div>
                      <!-- /.input group -->
                  </div>
              </div>

              <div class="mx-2">
                  <div class="form-group">
                      <label for="gares" class="text-muted">Gare(s) </label>
      
                      <div class="input-group">
                          <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fas fa-bus"></i></span>
                          </div>
                          <select name="gare_id" id="" class="form-control">
                              <?php if(Auth::user()->usertype == "admin" || Auth::user()->usertype == "comptable"): ?>
                                <option value="*">Toutes les gares</option>
                              <?php endif; ?>
                              <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->id); ?>" <?php echo e(session()->get('gare_id') == $item->id ? "selected" : ''); ?>><?php echo e($item->nom_gare); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                  </div>
              </div>
              <div class="mx-2">
                  <div class="form-group">
                      <label for="users" class="text-muted">Agent(s) </label>
      
                      <div class="input-group">
                          <div class="input-group-prepend">
                          <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                          </div>
                          <select name="users_id" id="" class="form-control">
                              <option value="*">Tous les agents</option>
                              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->id); ?>" <?php echo e(session()->get('users_id') == $item->id ? "selected" : ''); ?> data-id="<?php echo e($item->gare_id); ?>"><?php echo e($item->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                      </div>
                  </div>
              </div>
              <div class="mx-2">
                  <div class="form-group">
                      <label for="">&nbsp;</label>
                      <input type="submit" value="Chercher" class="form-control btn btn-success">
                      
                  </div>
              </div>
          </div>
      </form>
  </div>
</div>
<div class="row">
<div class="col-lg-4 col-6">
  <!-- small box -->
  <div class="small-box bg-success" style="color: black !important;">
    <div class="inner">
      <p><b>Jour <?php echo e(session()->has('start') ? "du ". date("d/m/Y", strtotime(session()->get('start'))) : ""); ?> <?php echo e(session()->has('end') && session()->get('start') != session()->get('end')? "au ". date("d/m/Y", strtotime(session()->get('end'))) : ""); ?> </b></p>
      <h3><?php echo e(number_format( session()->has('end') && session()->get('start') != session()->get('end')? $remises->sum('montant_remises') : $jour->sum('montant_remises'), 0 , '', ' ')); ?></h3>

    </div>
    <div class="icon">
      <i class="fa fa-briefcase"></i>
    </div>
    
  </div>
</div>
<!-- ./col -->
<div class="col-lg-4 col-6">
  <!-- small box -->
  <div class="small-box bg-warning" style="color: black !important;">
    <div class="inner">
      <p>Remises mensuelles (FCFA)</p>
      <h3><?php echo e(number_format($mois->sum('montant_remises'), 0 , '', ' ')); ?></h3>

    </div>
    <div class="icon">
      <i class="fas fa-suitcase"></i>
    </div>
    
  </div>
</div>
<!-- ./col -->
<div class="col-lg-4 col-6">
  <!-- small box -->
  <div class="small-box bg-danger" style="color: black !important;">
    <div class="inner">
      <p>Rémise Annuelle (FCFA)</p>
      <h3><?php echo e(number_format($year->sum('montant_remises'), 0 , '', ' ')); ?></h3>

    </div>
    <div class="icon">
      <i class="fas fa-coins"></i>
    </div>
    
  </div>
</div>
<!-- ./col -->
</div>

     <!-- Mes remises -->
     <div class="card direct-chat direct-chat-primary ">
        <div class="card-header">
          <h3 class="card-title"><strong>Démandes de rémises</strong></h3>

          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>
        <!-- /.card-header -->
          <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>GARE</th>
                  <th>BAGAGE</th>
                  <th>AGENT</th>
                  <th>QTE</th>
                  <th>MONTANT GLOBAL (FCFA)</th>
                  <th>REMISE (FCFA)</th>
                  <th>PAYÉ (FCFA)</th>
                  <th>TYPE</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                
                <?php $__currentLoopData = $remises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item->nom_gare); ?></td>
                    <td><?php echo e($item->type_bagage); ?></td>
                    <td><?php echo e($item->name); ?> <br> <?php echo e($item->phone); ?></td>
                    <td><?php echo e($item->nbr_de_bagage); ?></td>
                    <td><?php echo e(number_format($item->montant + $item->prix, 0, '', ' ')); ?></td>
                    <td><?php echo e(number_format($item->montant, 0, '', ' ')); ?></td>
                    <td><?php echo e(number_format($item->prix, 0, '', ' ')); ?></td>
                    <td><?php echo e($item->is_fret  ? "FRET" : "BUS"); ?></td>
                    <td>
                      <a class="btn bg-gradient-success" data-target="#detailBagage<?php echo e($item->bagage_id); ?>" data-toggle="modal"><i class="fa fa-eye"> Details</i></a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <tfoot>
                <tr>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td colspan="4" class="text-center">
                    <strong>TOTAL DES REMISES : <?php echo e(number_format($remises->sum('montant_remises'), 0, '', ' ') . " FCFA"); ?></strong>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
      </div>
      <!--/.Mes remises -->

      
     <!-- Mes remises -->
     <div class="card direct-chat direct-chat-primary ">
      <div class="card-header">
        <h3 class="card-title"><strong>Meilleur agent de remise.</strong></h3>
      </div>
      <!-- /.card-header -->
        <div class="card-body">
          <table id="example3" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>#</th>
                <th>AGENT</th>
                
                <th>QTE</th>
                
                <th>REMISE (FCFA)</th>
                
              </tr>
            </thead>
            <tbody>
              
              <?php $__currentLoopData = $remisesParAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td>
                    <?php if($users->where('id', $item->id)->first() != null): ?>
                    <?php echo e($users->where('id', $item->id)->first()->name); ?>

                    <?php endif; ?>
                  </td>
                  
                  <td><?php echo e($item->qte); ?></td>
                  
                  <td><?php echo e(number_format($item->montant_remises, 0, '', ' ')); ?></td>
                  
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
              <tr>
                <td></td>
                <td></td>
                <td colspan="3">
                  <strong>TOTAL DES REMISES : <?php echo e(number_format($remisesParAgent->sum('montant_remises'), 0, '', ' ') . " FCFA"); ?></strong>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
    </div>
    <!--/.Mes remises -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

  <?php $__currentLoopData = $remises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="detailBagage<?php echo e($item->bagage_id); ?>">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($item->nbr_de_bagage); ?> Bagages pour <?php echo e($item->name_passager); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
              <img src="https://ocl.ci/storage/bagages/<?php echo e($item->image); ?>" alt="les bagages de <?php echo e($item->name_passager); ?>" height="auto" width="100%">
              <table id="example7" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>DESCRIPTION</th>
                    <th>VALEUR EN PERTE</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $detailBagage->where('bagage_id',$item->bagage_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>#<?php echo e($item->id); ?></td>
                      <td><?php echo e($item->description); ?></td>
                      <td><?php echo e(number_format($item->valperte_detail, 0, '', ' '). " FCFA"); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>

            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
            </div>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/remises.blade.php ENDPATH**/ ?>