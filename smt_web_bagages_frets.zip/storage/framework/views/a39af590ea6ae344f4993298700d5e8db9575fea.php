

<?php $__env->startSection('title'); ?>
    Fiche suiveuse <?php echo e(session()->has('num_depart') ? session()->get('num_depart') : "" . session()->has('date') ? " du " .session()->get('date') : ""); ?> |
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
            <h1 class="m-0">Fiche suiveuse <?php echo e(session()->has('num_depart') ? session()->get('num_depart') : "" . session()->has('date') ? " du " .session()->get('date') : ""); ?></h1>
            </div>
        </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header d-flex justify-content-center">
                    <form action="<?php echo e(route('fiche-suiveuse-search')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <select name="id" id="" class="form-control">
                                        <?php $__currentLoopData = $departsHeureVille; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e(session()->get('id') == $item->id ? 'selected' : ''); ?>><?php echo e($item->nom_depart); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="date" name="date" id="date" value="<?php echo e(session()->has('date') ? session()->get('date') : ''); ?>" max="<?php echo e(date('Y-m-d')); ?>" required placeholder="Date de recherche" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <button class="btn btn-success"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <table id="example9" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>CODE</th>
                            <th>GARE</th>
                            <th>CLIENT</th>
                            <th>NUMERO</th>
                            <th>BAGAGE</th>
                            <th>QTE BAGAGE</th>
                            <th>MONTANT</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $liste; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#<?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($item->ref); ?></td>
                                <td>
                                    <?php echo e($gare->nom_gare); ?>

                                </td>
                                <td><?php echo e($item->name_passager); ?></td>
                                <td><?php echo e($item->phone_passager); ?></td>
                                <td><?php echo e($item->type_bagage); ?></td>
                                <td><?php echo e($item->nbr_de_bagage); ?></td>
                                <td><?php echo e(number_format($item->prix, 0, '', ' ')." FCFA"); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/chefdegare/fiche-suiveuse.blade.php ENDPATH**/ ?>