



<?php $__env->startSection('content'); ?>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
            <h1 class="m-0">Informations Bagages</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Bagage</a></li>
                <li class="breadcrumb-item active">Recherche</li>
            </ol>
            </div><!-- /.col -->
        </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->   

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header row">
                    <h5 class="col-sm-3">Recherche</h5>
                    <div class="col-sm-9 d-flex justify-content-end">
                        <form action="<?php echo e(route('search-ticket-bagage')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-8">
                                    <div class="form-group">
                                        <input type="text" name="ref" id="ref" placeholder="Code du bagage" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <button class="btn btn-success"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if($bagage != null): ?>
                <div class="card-body">
                    <table id="<?php echo e($bagage->is_solded == 1 ? 'example9': ''); ?>" class="table table-bordered">
                        
                        <thead>
                            <tr>
                                <th>LIBELLE</th>
                                <th>VALEUR</th>
                            </tr>
                        </thead>
                        <tbody style="color: black !important;">
                            <tr>
                                <td><strong style="font-size: 27px;">CODE</strong></td>
                                <td><strong style="font-size: 27px;"><?php echo e($bagage->ref); ?></strong></td>
                            </tr>
                            <tr>
                                <td><strong style="font-size: 27px;">NOM CLIENT</strong></td>
                                <td><strong style="font-size: 27px;"><?php echo e(ucfirst($bagage->name_passager)); ?></strong></td>
                            </tr>
                            <tr>
                                <td><strong style="font-size: 27px;">TYPE BAGAGE</strong></td>
                                <td><strong style="font-size: 27px;"><?php echo e($bagage->type_bagage); ?></strong></td>
                            </tr>
                            <tr>
                                <td><strong style="font-size: 27px;">DESTINATION</strong></td>
                                <td><strong style="font-size: 27px;"><?php echo e($bagage->trajet_ville); ?></strong></td>
                            </tr>
                            <tr>
                                <td><strong style="font-size: 27px;">MONTANT</strong></td>
                                <td><strong style="font-size: 27px;"><?php echo e(number_format($bagage->prix, 0, '', ' ')); ?></strong></td>
                            </tr>
                            <tr>
                                <td><strong style="font-size: 27px;">STATUS</strong></td>
                                <td>
                                    <strong style="font-size: 27px;">
                                        <?php if($bagage->is_solded == 1): ?>
                                            Payé
                                        <?php else: ?>
                                            <a class="btn btn-danger">Impayées</a>
                                            <a class="btn bg-gradient-success" data-target="#confirmPaiement<?php echo e($bagage->id); ?>" data-toggle="modal"><i class="fa fa-print"></i>Confirmer le paiement</a>
                                        <?php endif; ?>
                                    </strong>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php if($bagage != null): ?>
    <div class="modal fade" id="confirmPaiement<?php echo e($bagage->id); ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e($bagage->type_bagage); ?></h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <form action="<?php echo e(route('update-ticket-bagage', ['id'=> $bagage->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="modal-body">
                        <p><h4 class="text-center">Vous confirmez le paiement <br><?php echo e($bagage->nbr_de_bagage > 1 ? "des bagages" : "du bagage"); ?>  de <i><?php echo e($bagage->name_passager); ?></i>  pour un <br>montant de <i><?php echo e(number_format($bagage->prix, 0, '', ' '). " FCFA"); ?></i> ?  </h4></p>
                        <ul>
                            <li><strong>Code :</strong> <?php echo e($bagage->ref); ?></li>
                            <li><strong>Client :</strong> <?php echo e($bagage->name_passager); ?></li>
                            <li><strong>Téléphone :</strong> <?php echo e($bagage->phone_passager); ?></li>
                            <li><strong>Destination :</strong> <?php echo e($bagage->trajet_ville); ?></li>
                            <li><strong>Type de bagage :</strong> <?php echo e($bagage->type_bagage); ?></li>
                            <li><strong>Montant à payer :</strong> <?php echo e(number_format($bagage->prix, 0, '', ' '). " FCFA"); ?></li>
                        </ul>
                    </div>

                    <div class="modal-footer justify-content-right">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Non</button>
                        <button type="submit" class="btn btn-success">Oui</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/chefdegare/info-bagage.blade.php ENDPATH**/ ?>