

<?php $__env->startSection('content'); ?>
<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">TARIFS BAGAGES</h3>
          <a data-target="#addUser" data-toggle="modal" class="btn btn-primary">Ajouter</a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>Nature bagages</th>
                <th>Gare</th>
                <th>Taille</th>
                <th>Montant</th>
                <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($item->name_bagage); ?></td>
                  <td>
                    <?php if($gares->where('id', $item->gare_id)->first() != null): ?>
                        <?php echo e($gares->where('id', $item->gare_id)->first()->nom_gare); ?>

                    <?php endif; ?>
                  </td>
                  <td><?php echo e($item->taille); ?></td>
                  <td><?php echo e(number_format($item->montant_bagage, 0, '', ' ')); ?></td>
                  <td>
                      <a data-toggle="modal" data-target="#updateTarif_<?php echo e($item->id); ?>" class="btn btn-warning">
                          <i class="fa fa-edit text-white"> Éditer</i>
                      </a>
                      <a data-toggle="modal" data-target="#deleteTarif_<?php echo e($item->id); ?>" class="btn btn-danger">
                          <i class="fa fa-trash text-white"> Supprimer</i> 
                      </a>
                  </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="addUser">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('add-tarif-bagages')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <div class="modal-header">
          <h4 class="modal-title text-center">Ajouter une tarification Bagage</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="gare_id">Gare : </label>
                <select name="gare_id" id="gare_id" class="form-control">
                  <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == session()->get('gare_id') ? 'selected' : ''); ?>><?php echo e($item->nom_gare); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="name_bagage">Nom : </label>
                <input type="text" class="form-control" name="name_bagage" value="<?php echo e(old('name_bagage')); ?>" required>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="name_bagage">Taille : </label>
                <input list="listofsize" class="form-control" name="taille" value="<?php echo e(old('taille')); ?>">
                <datalist id="listofsize">
                  <option value="Petit">Petit</option>
                  <option value="Moyen">Moyen</option>
                  <option value="Grand">Grand</option>
                  <option value="Très Grand">Très Grand</option>
                </datalist>
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="montant_bagage">Montant : </label>
                <input type="number" min="0" class="form-control" name="montant_bagage" value="<?php echo e(old('montant_bagage')); ?>" required>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Créer</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>

<?php $__currentLoopData = $tarifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<div class="modal fade" id="updateTarif_<?php echo e($item->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('update-tarif-bagages')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
        <div class="modal-header">
          <h4 class="modal-title text-center">Modifier une tarification Bagage</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">

            <div class="col-sm-12">
              <div class="form-group">
                <label for="gare_id">Gare : </label>
                <select name="gare_id" id="gare_id" class="form-control">
                  <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($gare->id); ?>" <?php echo e($gare->id == $item->gare_id ? 'selected' : ''); ?>><?php echo e($gare->nom_gare); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="name_bagage">Nom : </label>
                <input type="text" class="form-control" name="name_bagage" value="<?php echo e($item->name_bagage); ?>" required> 
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="name_bagage">Taille : </label>
                <input list="listofsize" class="form-control" name="taille" value="<?php echo e($item->taille); ?>" >
                <datalist id="listofsize">
                  <option value="Petit">Petit</option>
                  <option value="Moyen">Moyen</option>
                  <option value="Grand">Grand</option>
                  <option value="Très Grand">Très Grand</option>
                </datalist>
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="montant_bagage">Montant : </label>
                <input type="number" min="0" class="form-control" name="montant_bagage" value="<?php echo e($item->montant_bagage); ?>" required>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Mettre à jour</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>
<div class="modal fade" id="deleteTarif_<?php echo e($item->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('delete-tarif-bagages', ['id'=> $item->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
        <div class="modal-header">
          <h4 class="modal-title text-center">Supprimer <?php echo e($item->taille . " " .strtolower($item->name_bagage)); ?> ?</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <p>Voulez-vous confirmer la suppression de ce article ?</p>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-danger">Supprimer</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/tarification-bagages.blade.php ENDPATH**/ ?>