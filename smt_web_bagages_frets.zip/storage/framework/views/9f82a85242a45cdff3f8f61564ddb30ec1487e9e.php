


<?php $__env->startSection('content'); ?>
<div class="card my-2">
    <div class="card-body mx-auto">
        <form action="<?php echo e(route('filtre')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row d-flex justify-content-center">
                <div class="mx-2">
                    <div class="form-group">
                        <label for="datestart" class="text-muted">Début </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                            </div>
                            <input type="date" id="datestart" class="form-control" name="start"  data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" inputmode="numeric" value="<?php echo e(session()->has('start') ? session()->get('start') : date('Y-m-d')); ?>">
                        </div>
                        <!-- /.input group -->
                    </div>
                </div>
                <div class="mx-2">
                    <div class="form-group">
                        <label for="dateend" class="text-muted">Fin </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                            </div>
                            <input type="date" id="dateend" class="form-control" name="end"  data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" inputmode="numeric" value="<?php echo e(session()->has('end') ? session()->get('end') : date('Y-m-d')); ?>">
                        </div>
                        <!-- /.input group -->
                    </div>
                </div>

                <div class="mx-2">
                    <div class="form-group">
                        <label for="gares" class="text-muted">Gare(s) </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-bus"></i></span>
                            </div>
                            <select name="gare_id" id="" class="form-control">
                                <?php if(Auth::user()->usertype == "admin" || Auth::user()->usertype == "comptable"): ?>
                                  <option value="*">Toutes les gares</option>
                                <?php endif; ?>
                                <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(session()->get('gare_id') == $item->id ? "selected" : ''); ?>><?php echo e($item->nom_gare); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mx-2">
                    <div class="form-group">
                        <label for="users" class="text-muted">Agent(s) </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-user-tie"></i></span>
                            </div>
                            <select name="users_id" id="" class="form-control">
                                <option value="*">Tous les agents</option>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(session()->get('users_id') == $item->id ? "selected" : ''); ?> data-id="<?php echo e($item->gare_id); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mx-2">
                    <div class="form-group">
                        <label for="">&nbsp;</label>
                        <input type="submit" value="Chercher" class="form-control btn btn-success">
                        
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="row">
  <div class="col-lg-4 col-6">
    <!-- small box -->
    <div class="small-box bg-success" style="color: black !important;">
      <div class="inner">
        <p>Montant Global Bagage (FCFA)</p>
        
        <h3><?php echo e(number_format($bagages->where('is_fret', 0)->sum('prix'), 0 , '', ' ')); ?></h3>

      </div>
      <div class="icon">
        <i class="fa fa-briefcase"></i>
      </div>
      
    </div>
  </div>
  <!-- ./col -->
  <div class="col-lg-4 col-6">
    <!-- small box -->
    <div class="small-box bg-warning" style="color: black !important;">
      <div class="inner">
        <p>Montant Global Fret (FCFA)</p>
        
        <h3><?php echo e(number_format($bagages->where('is_fret', 1)->sum('prix'), 0 , '', ' ')); ?></h3>

      </div>
      <div class="icon">
        <i class="fas fa-suitcase"></i>
      </div>
      
    </div>
  </div>
  <!-- ./col -->
  <div class="col-lg-4 col-6">
    <!-- small box -->
    <div class="small-box bg-danger" style="color: black !important;">
      <div class="inner">
        <p>Montant Global Fret & Bagage (FCFA)</p>
        <h3><?php echo e(number_format($rapportGares->sum('prix'), 0 , '', ' ')); ?></h3>
        

        
      </div>
      <div class="icon">
        <i class="fas fa-coins"></i>
      </div>
      
    </div>
  </div>
  <!-- ./col -->
</div>

<div class="row my-2">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">RAPPORT GBOBAL QTE | TRANSPORTS AVS</h3>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example3" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>TYPE</th>
                <th>Qte <sup>Impression</sup> </th>
                <th>Qte <sup>Bagages</sup> </th>
                <th>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>BAGAGES</td>
              <td><?php echo e(number_format($rapportType->where('is_fret', 0)->where('is_solded', 1)->count('prix'), 0, '', ' ')); ?></td>
              <td><?php echo e(number_format($rapportType->where('is_fret', 0)->where('is_solded', 1)->sum('nbr_de_bagage'), 0, '', ' ')); ?></td>
              <td><?php echo e(number_format($rapportType->where('is_fret', 0)->where('is_solded', 1)->sum('prix'), 0, '', ' ') . " FCFA"); ?></td>
            </tr>
            <tr>
              <td>FRET</td>
              <td><?php echo e(number_format($rapportType->where('is_fret', 1)->where('is_solded', 1)->count('prix'), 0, '', ' ')); ?></td>
              <td><?php echo e(number_format($rapportType->where('is_fret', 1)->where('is_solded', 1)->sum('nbr_de_bagage'), 0, '', ' ')); ?></td>
              <td><?php echo e(number_format($rapportType->where('is_fret', 1)->where('is_solded', 1)->sum('prix'), 0, '', ' ') . " FCFA"); ?></td>
            </tr>
          </tbody>
          
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>

<div class="row my-2">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">RAPPORT GARE | TRANSPORTS AVS</h3>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>Gare</th>
                <th>Qte <sup>Impression</sup></th>
                <th>Qte <sup>Bagages</sup></th>
                <th>Global</th>
                <th>Remise</th>
                <th>Total</th>
                <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $rapportGares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($gare->nom_gare); ?></td>
                <td><?php echo e(number_format($gare->qte_impression, 0, '', ' ')); ?></td>
                <td><?php echo e(number_format($gare->qte_bagage, 0, '', ' ')); ?></td>
                <td><?php echo e(number_format($gare->prix + $gare->montant_remises, 0, '', ' ')); ?></td>
                <td><?php echo e(number_format($gare->montant_remises, 0, '', ' ')); ?></td>
                <td><?php echo e(number_format($gare->prix, 0, '', ' ')); ?></td>
                <td class="text-center">
                    <a href="<?php echo e(route('gare-reports', ['id'=>$gare->id, 'user_id' => session()->has('users_id') ? session()->get('users_id') : '*', 'debut' => session()->has('start') ? session()->get('start') : date('Y-m-d'), 'fin' => session()->has('end') ? session()->get('end') : date('Y-m-d')])); ?>" class="btn btn-success">
                        <i class="fa fa-chart-pie"></i>
                        Rapport détaillé
                    </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>




<div class="row my-2">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">RAPPORT FILTRE | TRANSPORTS AVS</h3>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example3" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>ID</th>
                <th>JOUR</th>
                <th>QTE TICKET</th>
                <th>QTE BAGAGES</th>
                <th>MONTANT TOTAL</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $bagagesGroupedByCreatedAt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bagage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e(date('d/m/Y', strtotime($bagage->date))); ?></td>
                <td><?php echo e(number_format($bagage->nbr_tickets, 0, '', ' ')); ?></td>
                <td><?php echo e(number_format($bagage->nbr_bagages, 0, '', ' ')); ?></td>
                <td><?php echo e(number_format($bagage->prix, 0, '', ' ')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('customScripts'); ?>
  <!-- Page specific script -->
  <script>

      
      //-------------
      //- DONUT CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
      var donutData        = {
        labels: [
            'Adjame',
            'Yamoussoukro',
            'Boundiali',
            'Bouake',
            'Korhogo',
        ],
        datasets: [
          {
            data: [700,500,400,600,300],
            backgroundColor : ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc'],
          }
        ]
      }
      var donutOptions     = {
        maintainAspectRatio : false,
        responsive : true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(donutChartCanvas, {
        type: 'doughnut',
        data: donutData,
        options: donutOptions
      })

      //-------------
      //- PIE CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
      var pieData        = donutData;
      var pieOptions     = {
        maintainAspectRatio : false,
        responsive : true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(pieChartCanvas, {
        type: 'pie',
        data: pieData,
        options: pieOptions
      })

    });
  </script>

    <script>
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/rapport.blade.php ENDPATH**/ ?>