

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        Listes des tickets enrégistrés
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/lists-tickets.blade.php ENDPATH**/ ?>