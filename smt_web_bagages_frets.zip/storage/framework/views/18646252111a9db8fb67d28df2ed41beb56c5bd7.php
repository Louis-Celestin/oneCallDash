

<?php $__env->startSection('content'); ?>
<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">NOS VÉHICULES</h3>
          <a data-target="#addUser" data-toggle="modal" class="btn btn-primary">Ajouter</a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>ID SOLDE</th>
                <th>JOUR</th>
                <th>GARE</th>
                <th>MT BAGAGE</th>
                <th>Commission nornal</th>
                <th>Com stockée</th>
                <th>ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $bagages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->prix * 7 /100 != $soldes->where('date', $item->date)->first()->montant): ?>
                
            <tr>
                <td><?php echo e($loop->index + 1); ?></td>
                <td><?php echo e($soldes->where('date', $item->date)->first()->id); ?></td>
                <td><?php echo e($item->date); ?></td>
                <td>
                  <?php echo e($gare->nom_gare); ?>

                  
                </td>
                <td><?php echo e($item->prix); ?></td>
                <td><?php echo e($item->prix * 7 /100); ?></td>
                <td>
                    <?php if($soldes->where('date', $item->date)->first() != null): ?>
                        <?php echo e($soldes->where('date', $item->date)->first()->montant); ?>

                    <?php endif; ?>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="addUser">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('add-vehicules')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <div class="modal-header">
          <h4 class="modal-title text-center">Ajouter un véhicule</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="nom_vehicule">Nom du véhicule:  <span class="text-danger"><sup>*</sup></span> </label>
                <input type="text" class="form-control" name="nom_vehicule" value="<?php echo e(old('nom_vehicule')); ?>">
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="numero_vehicule">Numéro du véhicule:  <span class="text-danger"><sup>*</sup></span> </label>
                <input type="text" class="form-control" name="numero_vehicule" value="<?php echo e(old('numero_vehicule')); ?>">
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="type_de_vehicule">Type de véhicule: </label>
                <input type="text" class="form-control" name="type_de_vehicule" value="<?php echo e(old('type_de_vehicule')); ?>">
              </div>
            </div>

            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="nbre_de_place">Nombre de place:  <span class="text-danger"><sup>*</sup></span> </label>
                <input type="number" min="2" class="form-control" name="nbre_de_place" value="<?php echo e(old('nbre_de_place')); ?>">
              </div>
            </div>


          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Créer</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>

<?php $__currentLoopData = []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
<div class="modal fade" id="updateVehicule_<?php echo e($item->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('update-vehicules')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
        <div class="modal-header">
          <h4 class="modal-title text-center">Modifier un véhicule</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="nom_vehicule">Nom du véhicule:  <span class="text-danger"><sup>*</sup></span> </label>
                <input type="text" class="form-control" name="nom_vehicule" value="<?php echo e($item->nom_vehicule); ?>">
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="numero_vehicule">Numéro du véhicule:  <span class="text-danger"><sup>*</sup></span> </label>
                <input type="text" class="form-control" name="numero_vehicule" value="<?php echo e($item->numero_vehicule); ?>">
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <label for="type_de_vehicule">Type de véhicule: </label>
                <input type="text" class="form-control" name="type_de_vehicule" value="<?php echo e($item->type_de_vehicule); ?>">
              </div>
            </div>

            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="nbre_de_place">Nombre de place:  <span class="text-danger"><sup>*</sup></span> </label>
                <input type="number" min="2" class="form-control" name="nbre_de_place" value="<?php echo e($item->nbre_de_place); ?>">
              </div>
            </div>


          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Mettre à jour</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>
<div class="modal fade" id="deleteVehicule_<?php echo e($item->id); ?>">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('delete-vehicules', ['id'=> $item->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field("delete"); ?>
        <div class="modal-header">
          <h4 class="modal-title text-center">Supprimer <?php echo e($item->numero_vehicule . " " .strtolower($item->nom_vehicule)); ?> ?</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <p>Voulez-vous confirmer la suppression de ce article ?</p>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-danger">Supprimer</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/test3.blade.php ENDPATH**/ ?>