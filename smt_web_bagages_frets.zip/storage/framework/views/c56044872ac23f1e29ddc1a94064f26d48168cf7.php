

<?php $__env->startSection('content'); ?>
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Dashboard</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->
  
  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-danger" style="color: black !important;">
            <div class="inner">
              <p>Tickets Impayées</p>
              <h3><?php echo e($bagages->where('is_solded', 0)->count()); ?></h3>
  
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-info" style="color: black !important;">
            <div class="inner">
              <p>Montant Impayées (FCFA)</p>
              <h3><?php echo e(number_format($bagages->where('is_solded', 0)->sum('prix'), 0, '', ' ')); ?></h3>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-success" style="color: black !important;">
            <div class="inner">
              <p>Tickets Payées</p>
              <h3><?php echo e($bagages->where('is_solded', 1)->count()); ?></h3>
  
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-6">
          <!-- small box -->
          <div class="small-box bg-warning" style="color: black !important;">
            <div class="inner">
              <p>Montant Payés (FCFA)</p>
              <h3><?php echo e(number_format($bagages->where('is_solded', 1)->sum('prix'), 0, '', ' ')); ?></h3>
  
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->
      <!-- Main row -->
      <div class="row">
  
        
        <section class="col-lg-12  connectedSortable">
  
          <!-- Bagages Impayées du jour -->
          <div class="card direct-chat direct-chat-primary ">
            <div class="card-header">
              <h3 class="card-title"><strong>BAGAGE IMPAYÉS DU JOUR </strong></h3>
  
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-c ard-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>CODE</th>
                    <th>GARE</th>
                    <th>CLIENT</th>
                    <th>NUMERO</th>
                    <th>TYPE</th>   
                    <th>BAGAGE</th>
                    <th>QTE BAGAGE</th>
                    <th>MONTANT</th>
                    <th>PHOTO</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $bagages->where('is_solded', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>#<?php echo e($loop->index + 1); ?></td>
                      <td><?php echo e($item->ref); ?></td>
                      <td>
                        <?php echo e($gare->nom_gare); ?>

                      </td>
                      <td><?php echo e($item->name_passager); ?></td>
                      <td><?php echo e($item->phone_passager); ?></td>
                      <td>
                        <?php if($item->is_fret == 0): ?>
                            <?php echo e("BAGAGE"); ?>

                        <?php else: ?>
                          <?php echo e("FRET"); ?>

                        <?php endif; ?>
                      </td>
                      <td><?php echo e($item->type_bagage); ?></td>
                      <td><?php echo e($item->nbr_de_bagage); ?></td>
                      <td><?php echo e(number_format($item->prix, 0, '', ' ')." FCFA"); ?></td>
                      <td>
                        <?php if($item->image != null): ?>
                        <a class="btn bg-gradient-warning" data-target="#detailBagage<?php echo e($item->id); ?>" data-toggle="modal"><i class="fa fa-eye"></i></a>                         
                        <a class="btn bg-gradient-success" data-target="#confirmPaiement<?php echo e($item->id); ?>" data-toggle="modal"><i class="fa fa-check"></i></a>                               
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              
            </div>
            <!-- /.card-footer-->
          </div>
          <!--/.Bagages Impayées du jour -->

          <!-- Bagages Payées du jour -->
          <div class="card direct-chat direct-chat-primary ">
            <div class="card-header">
              <h3 class="card-title"><strong>BAGAGE PAYÉS DU JOUR </strong></h3>
  
              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse">
                  <i class="fas fa-minus"></i>
                </button>
                <button type="button" class="btn btn-tool" data-c ard-widget="remove">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example3" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>CODE</th>
                    <th>GARE</th>
                    <th>CLIENT</th>
                    <th>NUMERO</th>
                    <th>TYPE</th>
                    <th>BAGAGE</th>
                    <th>QTE BAGAGE</th>
                    <th>MONTANT</th>
                    <th>PHOTO</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $bagages->where('is_solded', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>#<?php echo e($loop->index + 1); ?></td>
                      <td><?php echo e($item->ref); ?></td>
                      <td>
                        <?php echo e($gare->nom_gare); ?>

                      </td>
                      <td><?php echo e($item->name_passager); ?></td>
                      <td><?php echo e($item->phone_passager); ?></td>
                      <td>
                        <?php if($item->is_fret == 0): ?>
                            <?php echo e("BAGAGE"); ?>

                        <?php else: ?>
                          <?php echo e("FRET"); ?>

                        <?php endif; ?>
                      </td>
                      <td><?php echo e($item->type_bagage); ?></td>
                      <td><?php echo e($item->nbr_de_bagage); ?></td>
                      <td><?php echo e(number_format($item->prix, 0, '', ' ')." FCFA"); ?></td>
                      <td>
                        <?php if($item->image != null): ?>
                        <a class="btn bg-gradient-warning" data-target="#detailBagage<?php echo e($item->id); ?>" data-toggle="modal"><i class="fa fa-eye"></i></a>                         
                        
                        
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              
            </div>
            <!-- /.card-footer-->
          </div>
          <!--/.Bagages Payées du jour -->
        </section>

      </div>
      <!-- /.row (main row) -->
    </div><!-- /.container-fluid -->
  </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
  <?php $__currentLoopData = $bagages->where('image', '!=', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="detailBagage<?php echo e($item->id); ?>">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($item->nbr_de_bagage); ?> Bagages pour <?php echo e($item->name_passager); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
              <img src="https://ocl.ci/storage/bagages/<?php echo e($item->image); ?>" alt="les bagages de <?php echo e($item->name_passager); ?>" height="auto" width="100%">
            </div>

            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
            </div>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>

    <div class="modal fade" id="confirmPaiement<?php echo e($item->id); ?>">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($item->type_bagage); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <form action="<?php echo e(route('update-ticket-bagage', ['id'=> $item->id])); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field("PUT"); ?>
              <div class="modal-body">
                <p><h4 class="text-center">Vous confirmez le paiement <br><?php echo e($item->nbr_de_bagage > 1 ? "des bagages" : "du bagage"); ?>  de <i><?php echo e($item->name_passager); ?></i>  pour un <br>montant de <i><?php echo e(number_format($item->prix, 0, '', ' '). " FCFA"); ?></i> ?  </h4></p>
                <ul>
                  <li><strong>Code :</strong> <?php echo e($item->ref); ?></li>
                  <li><strong>Client :</strong> <?php echo e($item->name_passager); ?></li>
                  <li><strong>Téléphone :</strong> <?php echo e($item->phone_passager); ?></li>
                  <li><strong>Destination :</strong> <?php echo e($item->trajet_ville); ?></li>
                  <li><strong>Type de bagage :</strong> <?php echo e($item->type_bagage); ?></li>
                  <li><strong>Montant à payer :</strong> <?php echo e(number_format($item->prix, 0, '', ' '). " FCFA"); ?></li>
                </ul>
              </div>
    
              <div class="modal-footer justify-content-right">
                <button type="button" class="btn btn-default" data-dismiss="modal">Non</button>
                <button type="submit" class="btn btn-success">Oui</button>
              </div>
            </form>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>

    <div class="modal fade" id="printBagage<?php echo e($item->id); ?>">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($item->type_bagage); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
              <p><h4 class="text-center">Vous confirmez le paiement <br><?php echo e($item->nbr_de_bagage > 1 ? "des bagages" : "du bagage"); ?>  de <i><?php echo e($item->name_passager); ?></i>  pour un <br>montant de <i><?php echo e(number_format($item->prix, 0, '', ' '). " FCFA"); ?></i> ?  </h4></p>
              <ul>
                <li><strong>Code :</strong> <?php echo e($item->ref); ?></li>
                <li><strong>Client :</strong> <?php echo e($item->name_passager); ?></li>
                <li><strong>Téléphone :</strong> <?php echo e($item->phone_passager); ?></li>
                <li><strong>Destination :</strong> <?php echo e($item->trajet_ville); ?></li>
                <li><strong>Type de bagage :</strong> <?php echo e($item->type_bagage); ?></li>
                <li><strong>Montant à payer :</strong> <?php echo e(number_format($item->prix, 0, '', ' '). " FCFA"); ?></li>
              </ul>
            </div>
  
            <div class="modal-footer justify-content-right">
              <button type="button" class="btn btn-default" data-dismiss="modal">Non</button>
              <button type="submit" class="btn btn-success">Imprimer</button>
            </div>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/chefdegare/index.blade.php ENDPATH**/ ?>