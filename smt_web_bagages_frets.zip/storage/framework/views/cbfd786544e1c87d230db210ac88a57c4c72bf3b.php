

<?php $__env->startSection('title'); ?>
    <?php echo e(session()->has('date') ? date('d-m-Y', strtotime(session()->get('date'))) : date('d-m-Y') ." TOTAL : ". number_format($rapports->sum('prix_depart'), 0, '', ' '). "F |"); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-header">

    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Rapport Journalier du  <?php echo e(session()->has('date') ? date('d-m-Y', strtotime(session()->get('date'))) : date('d-m-Y')); ?></h1>
            </div>
        </div>
    </div>

    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header d-flex justify-content-center">
                    <form action="<?php echo e(route('search-rapport-caissiere')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <input type="date" name="date" id="date" value="<?php echo e(session()->has('date') ? session()->get('date') : date('Y-m-d')); ?>" max="<?php echo e(date('Y-m-d')); ?>" required placeholder="Date de recherche" class="form-control">
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <button class="btn btn-success"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="card-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>DEPART</th>
                            <th>HEURE</th>
                            <th>QTE CLIENT</th>
                            <th>QTE BAGAGE</th>
                            <th>MONTANT</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rapports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>#<?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e($item->nom_depart); ?></td>
                                <td>
                                    <?php echo e($item->heure_depart); ?>

                                </td>
                                <td><?php echo e(number_format($item->qte_client, 0, '', ' ')); ?></td>
                                <td><?php echo e(number_format($item->qte_bagage, 0, '', ' ')); ?></td>
                                <td><?php echo e(number_format($item->prix_depart, 0, '', ' ')." FCFA"); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>TOTAL</td>
                                <td><?php echo e(number_format($rapports->sum('prix_depart'), 0, '', ' ')); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="card-body">
                    <table id="example9" class="table table-bordered table-striped">
                        <thead>
                        <tr>
                            <th>DATE</th>
                            <th>MONTANT</th>
                        </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e(session()->has('date') ? date('d-m-Y', strtotime(session()->get('date'))) : date('d-m-Y')); ?></td>
                                <td><?php echo e(number_format($rapports->sum('prix_depart'), 0, '', ' ')." FCFA"); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/chefdegare/rapport-journalier.blade.php ENDPATH**/ ?>