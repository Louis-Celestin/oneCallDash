<!-------------------------------------Start Y2R------------------------->

<style>
  .nav-link{color: #202124 !important; }
  .nav-item a p {color:black; }

  .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    background-color: #70b54c;
  }
</style>

<aside class="main-sidebar elevation-1" style="background: #ffef38;">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
      <img src="<?php echo e(asset('dist/img/logo_avs.jpg')); ?>" alt="OCL Logo" class="brand-image" style="max-height: 61px; width: 225px; object-fit: cover;">
      
    </a>
<!-------------------------------------End Y2R------------------------->



    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-5 pb-3 mb-3 d-flex justify-content-center">
        <div class="info">
          <a href="#" class="d-block text-center"><?php echo e(Auth::user()->name); ?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('dashboard-chefdegare')); ?>" class="nav-link <?php echo e(Route::current()->uri == "Tableau-de-bord-gare" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Tableau de bord
              </p>
            </a>
          </li>
          <?php if(Auth::user()->usertype == "chefgare"): ?>
            <li class="nav-item">
              <a href="<?php echo e(route('report')); ?>" class="nav-link <?php echo e(Route::current()->uri == "activités" || substr(Route::current()->uri, 0, strlen("rapports-detaillé-par-gare")) == "rapports-detaillé-par-gare" ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-tachometer-alt"></i>
                <p>
                  Rapport d'activités
                </p>
              </a>
            </li>
          <?php endif; ?>
          <li class="nav-item">
            <a href="<?php echo e(route('informations-bagage-payes')); ?>" class="nav-link <?php echo e(Route::current()->uri == "informations-bagage-payes" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-eye"></i>
              <p>
                Gestions des tickets
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('rapport-journalier-caissiere')); ?>" class="nav-link <?php echo e(Route::current()->uri == "rapport-journalier-caissiere" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-print"></i>
              <p>
                Rapport Journalier
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('fiche-suiveuse-index')); ?>" class="nav-link <?php echo e(Route::current()->uri == "fiche-suiveuse" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-bus"></i>
              <p>
                Fiche suiveuse
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('logout')); ?>" class="nav-link">
              <i class="nav-icon fa fa-door-open"></i>
              <p>
                Déconnexion
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/partials/chefdegare/_sidebar.blade.php ENDPATH**/ ?>