<?php $__env->startSection('content'); ?>
<div class="content-header">
  <div class="container-fluid">
    <div class="row mb-2">
      <div class="col-sm-6">
        <h1 class="m-0">Dashboard</h1>
      </div><!-- /.col -->
      <div class="col-sm-6">
        <ol class="breadcrumb float-sm-right">
          <li class="breadcrumb-item"><a href="#">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<section class="content">
  <div class="container-fluid">
    <!-- Small boxes (Stat box) -->
    <div class="row">
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info" style="color: black !important;">
          <div class="inner">
            <p>Qte FRET</p>
            <h3><?php echo e($todayBagage->where('is_fret', 1)->count()); ?></h3>

          </div>
          <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success" style="color: black !important;">
          <div class="inner">
            <p>Montant Fret (FCFA)</p>
            <h3><?php echo e(number_format($todayBagage->where('is_fret', 1)->sum('prix'), 0, '', ' ')); ?></h3>

          </div>
          <div class="icon">
            <i class="ion ion-pie-graph"></i>
          </div>
          
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning" style="color: black !important;">
          <div class="inner">
            <p>Qte bagage</p>
            <h3><?php echo e($todayBagage->where('is_fret', 0)->count()); ?></h3>

          </div>
          <div class="icon">
            <i class="ion ion-person-add"></i>
          </div>
          
        </div>
      </div>
      <!-- ./col -->
      <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger" style="color: black !important;">
          <div class="inner">
            <p>Montant Bagage (FCFA)</p>
            <h3><?php echo e(number_format($todayBagage->where('is_fret', 0)->sum('prix'), 0, '', ' ')); ?></h3>

          </div>
          <div class="icon">
            <i class="ion ion-pie-graph"></i>
          </div>
          
        </div>
      </div>
      <!-- ./col -->
    </div>
    <!-- /.row -->
    <!-- Main row -->
    <div class="row">

      <?php if($remises->count() > 0): ?>
      <!-- Right col -->
      <section class="col-lg-12  connectedSortable">
        <!-- Mes remises -->
        <div class="card direct-chat direct-chat-primary ">
          <div class="card-header">
            <h3 class="card-title"><strong>REMISES DU JOUR</strong></h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-card-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>GARE</th>
                  <th>BAGAGE</th>
                  <th>AGENT</th>
                  <th>MONTANT GLOBAL (FCFA)</th>
                  <th>REMISE (FCFA)</th>
                  <th>PAYÉ (FCFA)</th>
                  <th>TYPE</th>
                  <th>ACTIONS</th>
                </tr>
              </thead>
              <tbody>
                
                <?php $__currentLoopData = $remises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($item->nom_gare); ?></td>
                    <td><?php echo e($item->type_bagage); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e(number_format($item->montant + $item->prix, 0, '', ' ')); ?></td>
                    <td><?php echo e(number_format($item->montant, 0, '', ' ')); ?></td>
                    <td><?php echo e(number_format($item->prix, 0, '', ' ')); ?></td>
                    <td><?php echo e($item->is_fret  ? "FRET" : "BUS"); ?></td>
                    <td>
                      <a class="btn bg-gradient-success" data-target="#detailBagage<?php echo e($item->bagage_id); ?>" data-toggle="modal"><i class="fa fa-eye"> Details</i></a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div class="mt-2">
              <?php echo e($remises->links()); ?>

            </div>
          </div>
        </div>
        <!--/.Mes remises -->
      </section>
      <!-- /.Right col -->
      <?php endif; ?>


      
      <section class="col-lg-12  connectedSortable">

        <!-- Mes gares -->
        <div class="card direct-chat direct-chat-primary ">
          <div class="card-header">
            <h3 class="card-title"><strong>BAGAGE DU JOUR</strong></h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-c ard-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>GARE</th>
                  <th>CLIENT</th>
                  <th>NUMERO</th>
                  <th>BAGAGE</th>
                  <th>QTE BAGAGE</th>
                  <th>MONTANT</th>
                  <th>PHOTO</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $todayBagage->where('is_fret', 0); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td>#<?php echo e($item->id); ?></td>
                    <td>
                      <?php if($gares->where('id', $item->gare_id)->first() != null): ?>
                          <?php echo e($gares->where('id', $item->gare_id)->first()->nom_gare); ?>

                      <?php endif; ?>
                    </td>
                    <td><?php echo e($item->name_passager); ?></td>
                    <td><?php echo e($item->phone_passager); ?></td>
                    <td><?php echo e($item->type_bagage); ?></td>
                    <td><?php echo e($item->nbr_de_bagage); ?></td>
                    <td><?php echo e(number_format($item->prix, 0, '', ' ')." FCFA"); ?></td>
                    <td>
                      <?php if($item->image != null): ?>
                      <a class="btn bg-gradient-success" data-target="#detailBagage<?php echo e($item->id); ?>" data-toggle="modal"><i class="fa fa-eye"> Voir</i></a>                         
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
          <div class="card-footer">
            
          </div>
          <!-- /.card-footer-->
        </div>
        <!--/.Mes gares -->
      </section>


      <?php if($todayBagage->where('is_fret', 1)->count() >= 0): ?>
          
      <section class="col-lg-12  connectedSortable">

        <!-- Mes gares -->
        <div class="card direct-chat direct-chat-primary ">
          <div class="card-header">
            <h3 class="card-title"><strong>FRET DU JOUR</strong></h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-c ard-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="example2" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>GARE</th>
                  <th>CLIENT</th>
                  <th>NUMERO</th>
                  <th>BAGAGE</th>
                  <th>QTE BAGAGE</th>
                  <th>MONTANT</th>
                  <th>PHOTO</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $todayBagage->where('is_fret', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    
                    <td>#<?php echo e($item->id); ?></td>

                    <td>
                      <?php if($gares->where('id', $item->gare_id)->first() != null): ?>
                          <?php echo e($gares->where('id', $item->gare_id)->first()->nom_gare); ?>

                      <?php endif; ?>
                    </td>
                    <td><?php echo e($item->name_passager); ?></td>
                    <td><?php echo e($item->phone_passager); ?></td>
                    <td><?php echo e($item->type_bagage); ?></td>
                    <td><?php echo e($item->nbr_de_bagage); ?></td>
                    <td><?php echo e(number_format($item->prix, 0, '', ' ')." FCFA"); ?></td>
                    <td>
                      <?php if($item->image != null): ?>
                      <a class="btn bg-gradient-success" data-target="#detailBagage<?php echo e($item->id); ?>" data-toggle="modal"><i class="fa fa-eye"> Voir</i></a>                         
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        <!--/.Mes gares -->
      </section>
      <?php endif; ?>


      
      <!-- Left col -->
      <section class=" <?php echo e($remises->count() > 0 ? 'col-lg-12' : 'col-lg-12'); ?>  connectedSortable">

        <!-- Mes gares -->
        <div class="card direct-chat direct-chat-primary ">
          <div class="card-header">
            <h3 class="card-title"><strong>GARES</strong></h3>

            <div class="card-tools">
              <button type="button" class="btn btn-tool" data-card-widget="collapse">
                <i class="fas fa-minus"></i>
              </button>
              <button type="button" class="btn btn-tool" data-c ard-widget="remove">
                <i class="fas fa-times"></i>
              </button>
            </div>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <table id="" class="table table-bordered table-striped">
              <thead>
                <tr>
                  <th>GARE</th>
                  <th>NOMBRE DE BAGAGE</th>
                  <th>MONTANT</th>
                  <th>ACTION</th>
                </tr>
              </thead>
              <tbody>
                
                <?php $__currentLoopData = $todayBagage->groupBy('gare_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                  <tr>
                    <td>
                      <?php if($item[0]->gare_id != null): ?>
                          <?php echo e($gares->where('id', $item[0]->gare_id)->first()->nom_gare); ?>

                      <?php endif; ?>
                    </td>
                    <td><?php echo e($item->count()); ?></td>
                    <td><?php echo e(number_format($item->SUM('prix'), 0, '', ' ')); ?></td>
                    <td>
                      <a href="<?php echo e(route('gare-reports', ['id'=>$gares->where('id', $item[0]->gare_id)->first()->id, 'user_id' => session()->has('users_id') ? session()->get('users_id') : '*', 'debut' => session()->has('start') ? session()->get('start') : date('Y-m-d'), 'fin' => session()->has('end') ? session()->get('end') : date('Y-m-d')])); ?>" class="btn btn-success">
                        <i class="fa fa-chart-pie"></i>
                        Rapport détaillé
                    </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
              <?php if($todayBagage->groupBy('gare_id')->count() > 10): ?>
                <tfoot>
                  <tr>
                    <tr>
                      <th>GARE</th>
                      <th>NOMBRE DE BAGAGE</th>
                      <th>MONTANT (FCFA)</th>
                      <th>ACTION</th>
                    </tr>
                  </tr>
                </tfoot>
              <?php endif; ?>
            </table>
          </div>
        </div>
        <!--/.Mes gares -->
      </section>
      <!-- /.Left col -->
      


    </div>
    <!-- /.row (main row) -->
  </div><!-- /.container-fluid -->
</section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('modal'); ?>

  <?php $__currentLoopData = $todayBagage->where('image', '!=', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="detailBagage<?php echo e($item->id); ?>">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title"><?php echo e($item->nbr_de_bagage); ?> Bagages pour <?php echo e($item->name_passager); ?></h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
              <img src="https://ocl.ci/storage/bagages/<?php echo e($item->image); ?>" alt="les bagages de <?php echo e($item->name_passager); ?>" height="auto" width="100%">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>DESCRIPTION</th>
                    <th>VALEUR EN PERTE</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $detailBagage->where('bagage_id',$item->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>#<?php echo e($item->id); ?></td>
                      <td><?php echo e($item->description); ?></td>
                      <td><?php echo e(number_format($item->valperte_detail, 0, '', ' '). " FCFA"); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>

            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
            </div>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/index.blade.php ENDPATH**/ ?>