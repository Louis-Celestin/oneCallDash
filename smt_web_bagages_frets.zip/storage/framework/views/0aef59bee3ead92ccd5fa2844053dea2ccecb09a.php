

<?php $__env->startSection('content'); ?>
<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">Souscription</h3>
          <a data-target="#addUser" data-toggle="modal" class="btn btn-primary">Ajouter</a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>Gare</th>
                <th>Module</th>
                <th>TYPE D'OFFRE</th>
                <th>STATUS</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $enrollements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($item->nom_gare); ?></td>
                  <td>
                      <?php switch($item->id_module):
                          case (1): ?>
                              <?php echo e("BAGAGES & FRETS"); ?>

                              <?php break; ?>
                          <?php case (2): ?>
                              <?php echo e("COLIS"); ?>

                              <?php break; ?>
                          <?php default: ?>
                              <?php echo e("TICKETS"); ?>

                      <?php endswitch; ?>
                  </td>
                  <td>
                      <?php if($item->type_offre == 0): ?>
                          <?php echo e("PAR COMMISSION"); ?>

                      <?php endif; ?>
                  </td>
                  <td>
                      <?php if($item->actif): ?>

                        <a class="btn btn-success">
                            <i class="fa fa-check text-white"></i>
                        </a>

                      <?php else: ?>

                        <a class="btn btn-danger">
                            <i class="fa fa-times text-white"> Inactif</i> 
                        </a>

                      <?php endif; ?>


                  </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <?php if($enrollements->count() > 10): ?> 
          <tfoot>
            <tr>
                <th>Gare</th>
                <th>Module</th>
                <th>TYPE D'OFFRE</th>
                <th>STATUS</th>
            </tr>
          </tfoot>
          <?php endif; ?>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="addUser">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('souscribe')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <div class="modal-header">
          <h4 class="modal-title text-center">Souscrire pour une gare ? </h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">
            
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="gare">Choisissez la gare :</label>
                    <select name="id_gare" id="gare" class="form-control">
                        <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nom_gare); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            
            <div class="col-sm-12">
                <div class="form-group">
                    <label for="module">Le module :</label>
                    <select name="id_module" id="module" class="form-control">
                        <option value="1">BAGAGES & FRET</option>
                        <option value="2" disabled>COLIS</option>
                        <option value="3" disabled>TICKETS</option>
                    </select>
                </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="type_offre">Offre : </label>
                <input type="text" readonly class="form-control" name="type_offre" value="Par commission">
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Souscrire</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/subscribe.blade.php ENDPATH**/ ?>