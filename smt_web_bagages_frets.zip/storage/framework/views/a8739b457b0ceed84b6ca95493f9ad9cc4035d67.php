

<?php $__env->startSection('content'); ?>
<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">DEPARTS </h3>
          <a class="btn btn-primary" data-toggle="modal" data-target="#addDepart">Ajouter</a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>Gare</th>
                <th>Départ</th>
                <th>Heure</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $departs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td>
                    <?php if($gares->where('id', $item->ville_depart)->first() != null): ?>
                      <?php echo e($gares->where('id', $item->ville_depart)->first()->nom_gare); ?>

                    <?php endif; ?>
                  </td>
                  <td><?php echo e($item->nom_depart); ?></td>
                  <td><?php echo e($item->heure_depart); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="addDepart">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('save-departs')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <div class="modal-header">
          <h4 class="modal-title text-center">ENRÉGISTRER UN DÉPART</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="depart">Départ : </label>
                <select name="nom_depart" id="depart" class="form-control">
                  <?php for($i = 1; $i <= 200; $i++): ?>
                    <option value="Départ <?php echo e($i); ?>">Départ <?php echo e($i); ?></option>
                  <?php endfor; ?>
                </select>
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="departype">Type de départ : </label>
                <select name="is_depart_fret" id="departype" class="form-control">
                  <option value="0">BAGAGE</option>
                  <option value="1">FRET</option>
                </select>
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="heure_depart">Heure de départ : </label>
                <input type="time" name="heure_depart" id="heure_depart" class="form-control">
              </div>
            </div>

            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="depart">Ville de départ : </label>
                <select name="ville_depart" id="depart" class="form-control">
                  <option value="">--</option>
                  <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->nom_gare); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="arrive">Destination : </label>
                <select name="ville_destination" id="arrive" class="form-control">
                  <option value="">--</option>
                  <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($item->id); ?>"><?php echo e($item->nom_gare); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Créer</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/nos-departs.blade.php ENDPATH**/ ?>