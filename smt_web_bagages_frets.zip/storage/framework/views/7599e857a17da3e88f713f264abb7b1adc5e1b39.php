

<?php $__env->startSection('content'); ?>

  

  <div class="row my-5">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <div class="d-flex justify-content-between my-2">
            <h3 class="card-title">UTILISATEURS TRANSPORTS AVS</h3>
            <a data-target="#addUser" data-toggle="modal" class="btn btn-primary">Ajouter</a>
          </div>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
            <tr>
              <th>Nom</th>
              <th>Téléphone</th>
              <th>Gare</th>
              <th>Role</th>
              <th>Module</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e(ucfirst($item->name)); ?></td>
                  <td><?php echo e($item->phone); ?></td>
                  <td>
                    <?php if($gares->where('id', $item->gare_id)->first() != null): ?>
                        <?php echo e($gares->where('id', $item->gare_id)->first()->nom_gare); ?>

                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($item->usertype == "caissiere"): ?>
                        <?php echo e("Caissière"); ?>

                    <?php elseif($item->usertype == "chefgare"): ?>
                    <?php echo e("Chef de gare"); ?>

                    <?php else: ?>
                      <?php echo e(ucfirst($item->usertype)); ?>

                    <?php endif; ?>
                  </td>
                  <td>
                    <?php switch($item->id_module):
                        case (1): ?>
                            <?php echo e("Bagage"); ?>

                            <?php break; ?>
                        <?php case (2): ?>
                            <?php echo e("Colis"); ?>

                            <?php break; ?>
                        <?php case (3): ?>
                            <?php echo e("Ticket"); ?>

                            <?php break; ?>
                        <?php default: ?>
                    <?php endswitch; ?>
                  </td>
                  <td><?php echo e($item->email); ?></td>
                  <td>
                    <a data-toggle="modal" data-target="#EditUser<?php echo e($item->id); ?>Modal" class="btn btn-warning text-white">
                      <i class="fa fa-edit"></i>
                      
                  </a>
                  <a data-toggle="modal" data-target="#EraseUser<?php echo e($item->id); ?>Modal" class="btn btn-danger">
                      <i class="fa fa-eraser"></i>
                     
                  </a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <!-- /.card-body -->
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>

    
    <div class="modal fade" id="addUser">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <form action="<?php echo e(route('add-user')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
              <h4 class="modal-title">Créer un Utilisateur </h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div class="modal-body">
              <div class="row">
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="name">NOM :</label>
                    <input type="text" id="name" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="phone">TÉLÉPHONE :</label>
                    <input type="tel" id="phone" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>">
                  </div>
                </div>
                
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="gare_id">Gare:</label>
                    <select name="gare_id" class="form-control">
                      <option value="">---</option>
                      <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gare->id); ?>"><?php echo e($gare->nom_gare); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="form-group">
                    <label for="id_module">Module:</label>
                    <select name="id_module" class="form-control">
                      <option value="">---</option>
                      <option value="1">Bagage & Fret</option>
                      
                    </select>
                  </div>
                </div>
                <div class="col-sm-12">
                  <div class="form-group">
                    <label for="usertype">Poste:</label>
                    <select name="usertype" class="form-control">
                      <option value="admin">Administrateur</option>
                      <option value="caissiere">Caissière</option>
                      <option value="chefgare">Chef de gare</option>
                      <option value="comptable">Comptable</option>
                      <option value="agent">Gestionnaire(Agent)</option>
                    </select>
                  </div>
                </div>
                <div class="col-sm-12">
                  <div class="form-group">
                    <label for="email">E-mail :</label>
                    <input type="email" id="email" class="form-control" placeholder="Seulement réquis pour les admins et chef de gare" name="email" value="<?php echo e(old('email')); ?>">
                  </div>
                </div>
                <div class="col-sm-12">
                  <div class="form-group">
                    <label for="password">Mot de passe :</label>
                    <input type="password" id="password" class="form-control" name="password">
                  </div>
                </div>
              </div>
            </div>

            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
              <button type="submit" class="btn btn-warning">Ajouter</button>
            </div>
          </form>
        </div>
        <!-- /.modal-content -->
      </div>
    </div>
    

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <div class="modal fade" id="EditUser<?php echo e($item->id); ?>Modal">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <form action="<?php echo e(route('update-user')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field("PUT"); ?>
              <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
              <div class="modal-header">
                <h4 class="modal-title"><?php echo e($item->usertype); ?> <?php echo e($item->name); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
    
              <div class="modal-body">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="name">NOM :</label>
                      <input type="text" id="name" class="form-control" name="name" value="<?php echo e($item->name); ?>">
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="phone">TÉLÉPHONE :</label>
                      <input type="tel" id="phone" class="form-control" name="phone" value="<?php echo e($item->phone); ?>">
                    </div>
                  </div>
                  
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="gare_id">Gare:</label>
                      <select name="gare_id" class="form-control">
                        <option value="">---</option>
                        <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($gare->id); ?>" <?php echo e($item->gare_id == $gare->id ? 'selected' : ''); ?>><?php echo e($gare->nom_gare); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label for="id_module">Module:</label>
                      <select name="id_module" class="form-control">
                        <option value="">---</option>
                        <option value="1" <?php echo e($item->id_module == '1' ? 'selected' : ''); ?>>Bagage & Fret</option>
                        
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label for="usertype">Poste:</label>
                      <select name="usertype" class="form-control">
                        <option value="admin" <?php echo e($item->usertype == 'admin' ? 'selected' : ''); ?>>Administrateur</option>
                        <option value="caissiere" <?php echo e($item->usertype == 'caissiere' ? 'selected' : ''); ?>>Caissière</option>
                        <option value="chefgare" <?php echo e($item->usertype == 'chefgare' ? 'selected' : ''); ?>>Chef de gare</option>
                        <option value="comptable" <?php echo e($item->usertype == 'comptable' ? 'selected' : ''); ?>>Comptable</option>
                        <option value="agent" <?php echo e($item->usertype == 'agent' ? 'selected' : ''); ?>>Gestionnaire(Agent)</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label for="email">E-mail :</label>
                      <input type="email" id="email" class="form-control" placeholder="Seulement réquis pour les admins et chef de gare" name="email" value="<?php echo e($item->email); ?>">
                    </div>
                  </div>
                  <div class="col-sm-12">
                    <div class="form-group">
                      <label for="password">Mot de passe :</label>
                      <input type="password" id="password" placeholder="Remplir seulement si vous souhaitez changer son mot de passe" class="form-control" name="password">
                    </div>
                  </div>
                </div>
              </div>
    
              <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                <button type="submit" class="btn btn-warning">Mettre à jour</button>
              </div>
            </form>
          </div>
          <!-- /.modal-content -->
        </div>
      </div>
      

      
      <div class="modal fade" id="EraseUser<?php echo e($item->id); ?>Modal">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <form action="<?php echo e(route('destroy-user', ['id'=> $item->id])); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field("DELETE"); ?>
              <div class="modal-header">
                <h4 class="modal-title">Supprimer  <?php echo e($item->name); ?> ?</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
    
              <div class="modal-body">
                <p>Voulez-vous vraiment supprimer cet Utilisateur ?</p>
              </div>
    
              <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
                <button type="submit" class="btn btn-danger">Supprimer</button>
              </div>
            </form>
          </div>
          <!-- /.modal-content -->
        </div>
      </div>
      
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/user-lists.blade.php ENDPATH**/ ?>