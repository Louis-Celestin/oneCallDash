

<?php $__env->startSection('content'); ?>

<div class="row msy-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title">UTILISATEURS TRANSPORTS AVS</h3>
          <a data-target="#addUser" data-toggle="modal" class="btn btn-primary">Ajouter</a>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>Nom</th>
                <th>Ville</th>
                <th>Adresse</th>
                <th>Chef de Gare</th>
                <th class="text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($gare->nom_gare); ?></td>
                <td><?php echo e($gare->ville_gare); ?></td>
                <td><?php echo e($gare->adresse); ?></td>
                <td>
                  <?php if($gare->users_id != null): ?>
                    <?php echo e($users->where('id', $gare->users_id)->first() != null ? $users->where('id', $gare->users_id)->first()->name  ." (". $users->where('id', $gare->users_id)->first()->phone.")" : "Aucun"); ?></td>
                  <?php endif; ?>
                <td class="text-center">
                    <a href="<?php echo e(route('edit-gare', ['id' => $gare->id])); ?>" class="btn btn-warning text-white">
                        <i class="fa fa-edit"></i>
                        Modifier
                    </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tfoot>
            <tr>
              <th>Nom</th>
              <th>Ville</th>
              <th>Adresse</th>
              <th>Chef de Gare</th>
              <th class="text-center">Actions</th>
            </tr>
          </tfoot>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<div class="modal fade" id="addUser">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?php echo e(route('storeGare')); ?>" method="post">
        <?php echo csrf_field(); ?> 
        <div class="modal-header">
          <h4 class="modal-title text-center">Ajouter une gare</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>

        <div class="modal-body">
          <div class="row">
            
            <div class="col-sm-6">
              <div class="form-group">
                <label for="nom_gare">Nom : </label>
                <input type="text" class="form-control" name="nom_gare" value="<?php echo e(old('nom_gare')); ?>">
              </div>
            </div>
            
            <div class="col-sm-6">
              <div class="form-group">
                <label for="ville_gare">Ville : </label>
                <input type="text" class="form-control" name="ville_gare" value="<?php echo e(old('ville_gare')); ?>">
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <label for="adresse">Adresse : </label>
                <input type="text" class="form-control" name="adresse" value="<?php echo e(old('adresse')); ?>">
              </div>
            </div>
            
            <div class="col-sm-12">
              <div class="form-group">
                <select name="users_id" id="" class="form-control">
                  <option value="">--</option>
                  <?php $__currentLoopData = $users->where('usertype', 'chefgare'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Fermer</button>
          <button type="submit" class="btn btn-primary">Créer</button>
        </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('customScripts'); ?>
  <!-- Page specific script -->
  <script>

      
      //-------------
      //- DONUT CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var donutChartCanvas = $('#donutChart').get(0).getContext('2d')
      var donutData        = {
        labels: [
            'Adjame',
            'Yamoussoukro',
            'Boundiali',
            'Bouake',
            'Korhogo',
        ],
        datasets: [
          {
            data: [700,500,400,600,300],
            backgroundColor : ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc'],
          }
        ]
      }
      var donutOptions     = {
        maintainAspectRatio : false,
        responsive : true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(donutChartCanvas, {
        type: 'doughnut',
        data: donutData,
        options: donutOptions
      })

      //-------------
      //- PIE CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
      var pieData        = donutData;
      var pieOptions     = {
        maintainAspectRatio : false,
        responsive : true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(pieChartCanvas, {
        type: 'pie',
        data: pieData,
        options: pieOptions
      })

    });
  </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/gares-lists.blade.php ENDPATH**/ ?>