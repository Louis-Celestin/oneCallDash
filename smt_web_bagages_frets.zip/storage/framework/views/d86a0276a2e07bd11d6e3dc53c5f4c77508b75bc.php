<!-------------------------------------Start Y2R------------------------->

<style>
  .nav-link{color: #202124 !important; }
  .nav-item a p {color:black; }

  .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
    background-color: #70b54c;
  }
</style>

<aside class="main-sidebar elevation-1" style="background: #ffef38;">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('dashboard')); ?>" class="brand-link">
      <img src="<?php echo e(asset('dist/img/logo_avs.jpg')); ?>" alt="OCL Logo" class="brand-image" style="max-height: 61px; width: 225px; object-fit: cover;">
      
    </a>
<!-------------------------------------End Y2R------------------------->



    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-5 pb-3 mb-3 d-flex justify-content-center">
        <div class="info">
          <a href="#" class="d-block text-center"><?php echo e(Auth::user()->name); ?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(Route::current()->uri == "/" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Tableau de bord
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('report')); ?>" class="nav-link <?php echo e(Route::current()->uri == "activités" || substr(Route::current()->uri, 0, strlen("rapports-detaillé-par-gare")) == "rapports-detaillé-par-gare" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-eye"></i>
              <p>
                Rapport d'activités
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('informations-bagage-payes')); ?>" class="nav-link <?php echo e(Route::current()->uri == "informations-bagage-payes" ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-eye"></i>
              <p>
                Gestions des tickets
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('tickets-impayes')); ?>" class="nav-link <?php echo e(Route::current()->uri == "tickets-impayes" || substr(Route::current()->uri, 0, strlen("rapport-filtre-solded")) == "rapport-filtre-solded"  ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-file-invoice"></i>
              <p>
                Rapport Impayés
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('demandes-de-remises')); ?>" class="nav-link <?php echo e(Route::current()->uri == "gestion-de-remise" ? "active" : ""); ?>">
              <i class="nav-icon fa fa-percent"></i>
              <p>
                Gestion des rémises 
              </p>
            </a>
          </li>
          

          <li class="nav-item">
            <a href="#" class="nav-link <?php echo e((Route::current()->uri == "ocl-soldes" || Route::current()->uri == "nos-factures") ? "active" : ""); ?>">
              <i class="nav-icon fa fa-tools"></i>
              <p>
                Soldes & Factures
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('ocl-soldes')); ?>" class="nav-link <?php echo e(Route::current()->uri == "ocl-soldes" ? 'active' : ''); ?>">
                  &nbsp; &nbsp; &nbsp; <i class="fa fa-user-tie nav-icon"></i>
                  <p>Soldes</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('nos-factures')); ?>" class="nav-link <?php echo e(Route::current()->uri == "nos-factures" ? 'active' : ''); ?>">
                  &nbsp; &nbsp; &nbsp; <i class="fa fa-boxes nav-icon"></i>
                  <p>Factures</p>
                </a>
              </li>
            </ul>
          </li>

          
          <?php if(Auth::user()->usertype == "admin"): ?>
            <li class="nav-item">
              <a href="#" class="nav-link <?php echo e(Route::current()->uri == "nos-vehicules" || Route::current()->uri == "nos-conducteurs" || Route::current()->uri == "nos-departs" ? "active" : ""); ?>">
                <i class="nav-icon fa fa-tools"></i>
                <p>
                  Configuration
                  <i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="<?php echo e(route('user-lists')); ?>" class="nav-link <?php echo e(Route::current()->uri == "user-lists" ? 'active' : ''); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="fa fa-user-tie nav-icon"></i>
                    <p>Utilisateurs</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('gares-lists')); ?>" class="nav-link <?php echo e(Route::current()->uri == "gares-lists" ? 'active' : ''); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="fa fa-boxes nav-icon"></i>
                    <p>Gares</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('tarif-bagages-lists')); ?>" class="nav-link <?php echo e(Route::current()->uri == "tarification-bagages" ? "active" : ""); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="nav-icon fa fa-dollar-sign"></i>
                    <p>
                      Tarification
                    </p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('nos-vehicules')); ?>" class="nav-link <?php echo e(Route::current()->uri == "nos-vehicules" ? "active" : ""); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="fa fa-bus nav-icon"></i>
                    <p>Nos Véhicules</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('nos-conducteurs')); ?>" class="nav-link <?php echo e(Route::current()->uri == "nos-conducteurs" ? "active" : ""); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="fa fa-user-tie nav-icon"></i>
                    <p>Nos Chauffeurs</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('ours-departs')); ?>" class="nav-link <?php echo e(Route::current()->uri == "nos-departs" ? "active" : ""); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="fa fa-road nav-icon"></i>
                    <p>Départs</p>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('souscribers')); ?>" class="nav-link <?php echo e(Route::current()->uri == "souscrire" ? "active" : ""); ?>">
                    &nbsp; &nbsp; &nbsp; <i class="fa fa-star nav-icon"></i>
                    <p>Souscription</p>
                  </a>
                </li>
              </ul>
            </li>
          <?php endif; ?>
          <li class="nav-item">
            <a href="<?php echo e(route('logout')); ?>" class="nav-link">
              <i class="nav-icon fa fa-door-open"></i>
              <p>
                Déconnexion
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/partials/_sidebar.blade.php ENDPATH**/ ?>