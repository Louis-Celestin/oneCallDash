


<?php $__env->startSection('content'); ?>
<div class="container">

  <div class="card my-2" style="background-color: #ffef38;">
    <div class="card-body mx-auto">
        <form action="<?php echo e(route('filtreImpayepart')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row d-flex justify-content-center">
                <div class="mx-2">
                    <div class="form-group">
                        <label for="datestart" class="text-mutded">Début </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                            </div>
                            <input type="date" id="datestart" class="form-control" name="start" placeholder="ds"  data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" inputmode="numeric" value="<?php echo e(session()->has('start') ? session()->get('start') : date('Y-01-01')); ?>">
                        </div>
                        <!-- /.input group -->
                    </div>
                </div>
                <div class="mx-2">
                    <div class="form-group">
                        <label for="dateend" class="text-mutded">Fin </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="far fa-calendar-alt"></i></span>
                            </div>
                            <input type="date" id="dateend" class="form-control" name="end"  data-inputmask-alias="datetime" data-inputmask-inputformat="dd/mm/yyyy" data-mask="" inputmode="numeric" value="<?php echo e(session()->has('end') ? session()->get('end') : date('Y-m-d')); ?>">
                        </div>
                        <!-- /.input group -->
                    </div>
                </div>
  
                <div class="mx-2">
                    <div class="form-group">
                        <label for="gares" class="text-mutded">Gare(s) </label>
        
                        <div class="input-group">
                            <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-bus"></i></span>
                            </div>
                            <select name="gare_id" id="" class="form-control">
                                <option value="*">Toutes les gares</option>
                                <?php $__currentLoopData = $gares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(session()->get('gare_id') == $item->id ? "selected" : ''); ?>><?php echo e($item->nom_gare); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mx-2">
                    <div class="form-group">
                        <label for="">&nbsp;</label>
                        <input type="submit" value="Chercher" class="form-control btn btn-success">
                        
                    </div>
                </div>
            </div>
        </form>
    </div>
  </div>
</div>
<div class="row">

  
    
  </div>


<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title"><?php echo e($is_fret == 1 ? "FRET" : "BAGAGES"); ?> <?php echo e($is_solded == 1 ? "PAYÉS" : "IMPAYÉS"); ?> </h3>
          
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>DATE</th>
                <th>HEURE</th>
                <th>CODE</th>
                <th>GARE</th>
                <th>CLIENT</th>
                <th>BAGAGE</th>
                <th>QUANTITE</th>
                <th>PRIX</th>
                <th>PHOTO</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td>
                    <?php echo e(date('d-m-Y', strtotime($item->created_at))); ?>

                  </td>
                  <td>
                    <?php echo e(date('H:i', strtotime($item->created_at))); ?>

                  </td>
                  <td><?php echo e($item->ref); ?></td>
                  <td><?php echo e($item->nom_gare); ?></td>
                  <td><?php echo e($item->name_passager); ?></td>
                  <td><?php echo e($item->type_bagage); ?></td>
                  <td><?php echo e($item->nbr_de_bagage); ?></td>
                  <td><?php echo e(number_format($item->prix, 0, '', ' ')); ?></td>
                  <td>
                      <a href="https://ocl.ci/storage/bagages/<?php echo e($item->image); ?>" target="_blank" class="btn btn-secondary"> Voir l'image</a>
                  </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<div class="row my-5">
  <div class="col-sm-12">
    <div class="card">
      <div class="card-header">
        <div class="d-flex justify-content-between my-2">
          <h3 class="card-title"><?php echo e($is_solded == 1 ? "PAYÉS" : "IMPAYÉS"); ?> PAR GARE</h3>
          
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="example3" class="table table-bordered table-striped">
          <thead>
            <tr>
                <th>#</th>
                <th>GARE</th>
                <th>QTE CLIENT</th>
                <th>QTE BAGAGE</th>
                <th>MONTANT ( FCFA )</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $impayesGroupByGare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($loop->index + 1); ?></td>
                  <td><?php echo e($item->nom_gare); ?></td>
                  <td><?php echo e(number_format($item->qte_client, 0, '', ' ')); ?></td>
                  <td><?php echo e(number_format($item->qte_bagage, 0, '', ' ')); ?></td>
                  <td><?php echo e(number_format($item->prix_gare, 0, '', ' ')); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\avs_ocl_web\resources\views/rapport-filtre-solded.blade.php ENDPATH**/ ?>