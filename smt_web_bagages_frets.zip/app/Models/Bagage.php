<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bagage extends Model
{
    protected $table = 'bagage';
    protected $guarded = [];
    use HasFactory;
}
