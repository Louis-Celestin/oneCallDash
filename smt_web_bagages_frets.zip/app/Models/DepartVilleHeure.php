<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DepartVilleHeure extends Model
{
    use HasFactory;
    protected $table = 'depart_ville_heure';
    protected $guarded = [];
}
